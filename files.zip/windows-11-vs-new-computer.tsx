import type { BlogPost } from "@/lib/posts";

const post: BlogPost = {
  slug: "windows-11-vs-new-computer",
  title: "Your Computer Doesn't Support Windows 11 — Now What?",
  excerpt:
    "Windows 10 support ended in October 2025. If your machine can't run Windows 11, here's an honest look at whether to buy new, go refurbished, or get extended support.",
  date: "2026-02-16",
  Body: () => (
    <>
      {/* MIGRATE: Paste your existing article JSX from app/blog/windows-11-vs-new-computer/page.tsx here */}
      <p>Article content goes here.</p>
    </>
  ),
};

export default post;
