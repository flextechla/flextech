import type { BlogPost } from "@/lib/posts";

const post: BlogPost = {
  slug: "protect-yourself-from-phishing",
  title: "How to Protect Yourself from Phishing Attacks",
  excerpt:
    "Phishing attacks are one of the most common cyber threats today. Learn how to recognize and avoid them with these practical tips.",
  date: "2025-01-15",
  Body: () => (
    <>
      {/* MIGRATE: Paste your existing article JSX from app/blog/protect-yourself-from-phishing/page.tsx here */}
      <p>Article content goes here.</p>
    </>
  ),
};

export default post;
