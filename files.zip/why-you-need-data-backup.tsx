import type { BlogPost } from "@/lib/posts";

const post: BlogPost = {
  slug: "why-you-need-data-backup",
  title: "Why Every Business Needs a Data Backup Plan",
  excerpt:
    "Data loss can happen to anyone. A solid backup strategy is your best insurance against hardware failure, ransomware, and human error.",
  date: "2024-09-10",
  Body: () => (
    <>
      {/* MIGRATE: Paste your existing article JSX from app/blog/why-you-need-data-backup/page.tsx here */}
      <p>Article content goes here.</p>
    </>
  ),
};

export default post;
