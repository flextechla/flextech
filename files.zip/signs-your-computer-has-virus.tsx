import type { BlogPost } from "@/lib/posts";

const post: BlogPost = {
  slug: "signs-your-computer-has-virus",
  title: "5 Signs Your Computer Might Have a Virus",
  excerpt:
    "Is your computer running slow, showing pop-ups, or behaving strangely? Here are the telltale signs of a virus infection and what to do about it.",
  date: "2024-11-20",
  Body: () => (
    <>
      {/* MIGRATE: Paste your existing article JSX from app/blog/signs-your-computer-has-virus/page.tsx here */}
      <p>Article content goes here.</p>
    </>
  ),
};

export default post;
